const cells = document.querySelectorAll('[data-cell]');
const gameBoard = document.getElementById('game-board');
const statusDisplay = document.getElementById('game-status');
const restartButton = document.getElementById('restart-button');

let currentPlayer = 'X';
let isGameActive = true;

const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
];

const checkWinner = () => {
    let roundWon = false;
    const cellValues = Array.from(cells).map(cell => cell.textContent);

    for (let condition of winningConditions) {
        const [a, b, c] = condition;
        if (cellValues[a] && cellValues[a] === cellValues[b] && cellValues[a] === cellValues[c]) {
            roundWon = true;
            break;
        }
    }

    if (roundWon) {
        statusDisplay.textContent = `Player ${currentPlayer} wins!`;
        isGameActive = false;
    } else if (cellValues.every(cell => cell)) {
        statusDisplay.textContent = 'Draw!';
        isGameActive = false;
    }
};

const handleCellClick = (e) => {
    const cell = e.target;

    if (cell.textContent || !isGameActive) return;

    cell.textContent = currentPlayer;
    cell.classList.add('taken');

    checkWinner();

    if (isGameActive) {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        statusDisplay.textContent = `Player ${currentPlayer}'s turn`;
    }
};

const restartGame = () => {
    currentPlayer = 'X';
    isGameActive = true;
    statusDisplay.textContent = `Player ${currentPlayer}'s turn`;
    cells.forEach(cell => {
        cell.textContent = '';
        cell.classList.remove('taken');
    });
};

cells.forEach(cell => cell.addEventListener('click', handleCellClick));
restartButton.addEventListener('click', restartGame);

restartGame(); // Initialize game state
